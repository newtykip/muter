# muter

## To-do

- Cross-platform?

## Integrations

### Discord

- [Vencord](https://vencord.dev/)
    - [Source code](https://git.newty.dev/newt/Vencord/src/branch/feat/muter/src/plugins/muter/index.ts)

<sub>this code is licensed with the <a href="license.md">opinionated queer license v1.2</a></sub>